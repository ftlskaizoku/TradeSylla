# Trading Journal — Local App

A local web app for logging JP225 (Nikkei) and Gold trade setups by screenshot + free-text
reasoning, then mining that text for recurring keywords, phrases, and win-rate correlations.

Everything runs on your machine. Screenshots are stored in `uploads/`, all trade data in a
local SQLite file `trading_journal.db`. Nothing leaves your computer.

## Setup (one time)

You need Python 3.9+ installed. Then, from this folder:

```bash
python3 -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Running the app

```bash
source venv/bin/activate        # if not already active
python3 app.py
```

Then open **http://localhost:5000** in your browser. Leave the terminal running while you use it;
close it (Ctrl+C) when you're done.

## How to use it

1. **Add Trade Day** — for each setup you took, upload the screenshot(s), pick the instrument
   (JP225 or Gold), and write out what led you to take the trade in the notes box. This is the
   most important part — write like you're explaining it to yourself later. Mark the outcome
   (win/loss/breakeven) once you know it, or leave it pending.
2. **Trades** (home page) — browse everything you've logged, filter by instrument or outcome.
3. **Stats & Patterns** — once you've got a handful of trades in, this page shows:
   - Most frequent words/phrases across all your reasoning notes
   - A word-vs-win-rate table: which words in your notes show up more often in wins vs losses
   - Vocabulary broken out by instrument (JP225 vs Gold), so you can see if your language/patterns
     differ between the two

The keyword engine is intentionally simple right now (frequency counting + stopword filtering,
pure Python, no external NLP libraries) so it's fast and dependency-free. As you log more trades,
patterns worth digging into will surface in the win-rate table — words with a notably high or low
win rate relative to their frequency.

## Data model — built to grow

The database already has (nullable, currently optional) columns for **direction, session,
setup_type, and R:R**. You can fill these in per-trade now, or leave them blank and add a proper
tagging UI later — no schema change needed when you're ready to make tagging structured/mandatory.

## Where things live

```
trading_journal/
├── app.py                 # Flask app / routes
├── db.py                  # SQLite schema + connection helper
├── keyword_extractor.py   # word/phrase frequency + win-rate correlation logic
├── templates/             # HTML pages
├── static/css/style.css   # styling
├── uploads/                # your screenshots (created automatically)
└── trading_journal.db     # your database (created automatically on first run)
```

## Backing up your data

Just copy the `trading_journal.db` file and the `uploads/` folder somewhere safe. That's your
entire dataset.

## Ideas for "pushing it further" later

- Swap the keyword engine for embeddings-based clustering (e.g. sentence-transformers) to group
  semantically similar setups even when you use different wording
- Add a proper tagging UI (dropdowns that learn from past entries) instead of free-text
  session/setup_type fields
- Charts (equity curve, win rate over time, win rate by session) — Chart.js drops in easily
- Export to CSV for further analysis in a spreadsheet or notebook
- OCR on the screenshots themselves to auto-extract price levels/times shown in the chart
