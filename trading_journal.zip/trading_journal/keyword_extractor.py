"""
Lightweight keyword / pattern extraction over free-text trade notes.
No external NLP dependencies -- pure standard library, so the app stays
easy to run locally. Can be swapped later for a heavier NLP/embeddings
approach once you have more data.
"""

import re
from collections import Counter, defaultdict

STOPWORDS = set("""
a about above after again against all am an and any are aren't as at be because been
before being below between both but by can't cannot could couldn't did didn't do does
doesn't doing don't down during each few for from further had hadn't has hasn't have
haven't having he he'd he'll he's her here here's hers herself him himself his how
how's i i'd i'll i'm i've if in into is isn't it it's its itself let's me more most
mustn't my myself no nor not of off on once only or other ought our ours ourselves out
over own same shan't she she'd she'll she's should shouldn't so some such than that
that's the their theirs them themselves then there there's these they they'd they'll
they're they've this those through to too under until up very was wasn't we we'd we'll
we're we've were weren't what what's when when's where where's which while who who's
whom why why's with won't would wouldn't you you'd you'll you're you've your yours
yourself yourselves it's im its trade traded trading today saw took entry set setup
""".split())

TOKEN_RE = re.compile(r"[a-zA-Z']+")


def tokenize(text):
    if not text:
        return []
    words = TOKEN_RE.findall(text.lower())
    return [w for w in words if w not in STOPWORDS and len(w) > 2]


def bigrams(tokens):
    return [f"{a} {b}" for a, b in zip(tokens, tokens[1:])]


def analyze_trades(trades):
    """
    trades: list of dicts with keys: notes, outcome, instrument
    Returns a dict with:
      - top_words: overall word frequency
      - top_phrases: overall bigram frequency
      - by_outcome: word frequency split by outcome (win/loss)
      - by_instrument: word frequency split by instrument
      - keyword_win_rate: for words appearing >=2 times, win rate when present
    """
    overall_words = Counter()
    overall_bigrams = Counter()
    words_by_outcome = defaultdict(Counter)
    words_by_instrument = defaultdict(Counter)

    # For win-rate correlation: word -> {"win":n, "loss":n, "total":n}
    word_outcome_stats = defaultdict(lambda: {"win": 0, "loss": 0, "breakeven": 0, "total": 0})

    for t in trades:
        tokens = tokenize(t.get("notes", ""))
        unique_tokens = set(tokens)
        overall_words.update(tokens)
        overall_bigrams.update(bigrams(tokens))

        outcome = (t.get("outcome") or "").lower()
        instrument = t.get("instrument", "unknown")

        if outcome:
            words_by_outcome[outcome].update(unique_tokens)
        words_by_instrument[instrument].update(unique_tokens)

        for w in unique_tokens:
            word_outcome_stats[w]["total"] += 1
            if outcome in ("win", "loss", "breakeven"):
                word_outcome_stats[w][outcome] += 1

    # Build win-rate table only for words with enough occurrences to mean something
    keyword_win_rate = []
    for w, stats in word_outcome_stats.items():
        decided = stats["win"] + stats["loss"]
        if decided >= 2:  # need at least 2 decided trades mentioning this word
            keyword_win_rate.append({
                "word": w,
                "occurrences": stats["total"],
                "wins": stats["win"],
                "losses": stats["loss"],
                "win_rate": round(100 * stats["win"] / decided, 1)
            })
    keyword_win_rate.sort(key=lambda r: (-r["occurrences"], -r["win_rate"]))

    return {
        "top_words": overall_words.most_common(30),
        "top_phrases": overall_bigrams.most_common(20),
        "by_outcome": {k: v.most_common(15) for k, v in words_by_outcome.items()},
        "by_instrument": {k: v.most_common(15) for k, v in words_by_instrument.items()},
        "keyword_win_rate": keyword_win_rate[:25],
    }
