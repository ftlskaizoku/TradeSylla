import os
import uuid
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash

from db import get_connection, init_db, DB_PATH
from keyword_extractor import analyze_trades

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXT = {"png", "jpg", "jpeg", "gif", "webp"}

app = Flask(__name__)
app.secret_key = "local-dev-only-change-if-you-deploy"
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024  # 32MB per request

os.makedirs(UPLOAD_DIR, exist_ok=True)
if not os.path.exists(DB_PATH):
    init_db()
else:
    init_db()  # safe: CREATE TABLE IF NOT EXISTS


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


@app.route("/")
def index():
    instrument_filter = request.args.get("instrument", "all")
    outcome_filter = request.args.get("outcome", "all")

    conn = get_connection()
    query = "SELECT * FROM trades WHERE 1=1"
    params = []
    if instrument_filter != "all":
        query += " AND instrument = ?"
        params.append(instrument_filter)
    if outcome_filter != "all":
        query += " AND outcome = ?"
        params.append(outcome_filter)
    query += " ORDER BY trade_date DESC, id DESC"

    trades = conn.execute(query, params).fetchall()

    # attach screenshots
    trades_out = []
    for t in trades:
        shots = conn.execute(
            "SELECT * FROM screenshots WHERE trade_id = ?", (t["id"],)
        ).fetchall()
        trades_out.append({**dict(t), "screenshots": [dict(s) for s in shots]})

    conn.close()
    return render_template(
        "index.html",
        trades=trades_out,
        instrument_filter=instrument_filter,
        outcome_filter=outcome_filter,
    )


@app.route("/add", methods=["GET", "POST"])
def add_trade():
    if request.method == "POST":
        trade_date = request.form.get("trade_date")
        instrument = request.form.get("instrument")
        notes = request.form.get("notes", "")
        outcome = request.form.get("outcome") or None
        direction = request.form.get("direction") or None
        session = request.form.get("session") or None
        setup_type = request.form.get("setup_type") or None
        rr = request.form.get("rr") or None

        if not trade_date or not instrument:
            flash("Date and instrument are required.", "error")
            return redirect(url_for("add_trade"))

        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO trades (trade_date, instrument, notes, outcome, direction, session, setup_type, rr)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (trade_date, instrument, notes, outcome, direction, session, setup_type, rr),
        )
        trade_id = cur.lastrowid

        files = request.files.getlist("screenshots")
        for f in files:
            if f and f.filename and allowed_file(f.filename):
                ext = f.filename.rsplit(".", 1)[1].lower()
                stored_name = f"{trade_id}_{uuid.uuid4().hex[:8]}.{ext}"
                f.save(os.path.join(UPLOAD_DIR, stored_name))
                cur.execute(
                    "INSERT INTO screenshots (trade_id, filename) VALUES (?, ?)",
                    (trade_id, stored_name),
                )

        conn.commit()
        conn.close()
        flash("Trade day saved.", "success")
        return redirect(url_for("index"))

    return render_template("add_trade.html")


@app.route("/trade/<int:trade_id>")
def trade_detail(trade_id):
    conn = get_connection()
    trade = conn.execute("SELECT * FROM trades WHERE id = ?", (trade_id,)).fetchone()
    if trade is None:
        conn.close()
        return "Trade not found", 404
    shots = conn.execute(
        "SELECT * FROM screenshots WHERE trade_id = ?", (trade_id,)
    ).fetchall()
    conn.close()
    return render_template("trade_detail.html", trade=dict(trade), screenshots=[dict(s) for s in shots])


@app.route("/trade/<int:trade_id>/delete", methods=["POST"])
def delete_trade(trade_id):
    conn = get_connection()
    shots = conn.execute("SELECT * FROM screenshots WHERE trade_id = ?", (trade_id,)).fetchall()
    for s in shots:
        path = os.path.join(UPLOAD_DIR, s["filename"])
        if os.path.exists(path):
            os.remove(path)
    conn.execute("DELETE FROM trades WHERE id = ?", (trade_id,))
    conn.commit()
    conn.close()
    flash("Trade deleted.", "success")
    return redirect(url_for("index"))


@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)


@app.route("/stats")
def stats():
    instrument_filter = request.args.get("instrument", "all")
    conn = get_connection()
    query = "SELECT * FROM trades WHERE 1=1"
    params = []
    if instrument_filter != "all":
        query += " AND instrument = ?"
        params.append(instrument_filter)
    trades = [dict(r) for r in conn.execute(query, params).fetchall()]
    conn.close()

    total = len(trades)
    decided = [t for t in trades if (t["outcome"] or "").lower() in ("win", "loss", "breakeven")]
    wins = len([t for t in decided if t["outcome"].lower() == "win"])
    losses = len([t for t in decided if t["outcome"].lower() == "loss"])
    win_rate = round(100 * wins / len(decided), 1) if decided else None

    analysis = analyze_trades(trades)

    counts_by_instrument = {}
    for t in trades:
        counts_by_instrument[t["instrument"]] = counts_by_instrument.get(t["instrument"], 0) + 1

    return render_template(
        "stats.html",
        total=total,
        wins=wins,
        losses=losses,
        win_rate=win_rate,
        analysis=analysis,
        instrument_filter=instrument_filter,
        counts_by_instrument=counts_by_instrument,
    )


if __name__ == "__main__":
    app.run(debug=True, port=5000)
