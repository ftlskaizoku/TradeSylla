import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trading_journal.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trade_date TEXT NOT NULL,
            instrument TEXT NOT NULL,           -- 'JP225' or 'Gold'
            notes TEXT,                         -- free text explanation of the setup / reasoning
            outcome TEXT,                       -- 'win' | 'loss' | 'breakeven' | 'pending' | NULL
            direction TEXT,                     -- 'long' | 'short' | NULL (structured, add later)
            session TEXT,                       -- e.g. 'Asia', 'London', 'NY' (structured, add later)
            setup_type TEXT,                    -- e.g. 'breakout', 'reversal' (structured, add later)
            rr REAL,                            -- risk:reward realized or planned (structured, add later)
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS screenshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trade_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            uploaded_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (trade_id) REFERENCES trades (id) ON DELETE CASCADE
        )
    """)
    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    print(f"Database initialized at {DB_PATH}")
